job-search


A web app which scraps the results of several job board sites and brings them together in one web page.

Location specification - [City, State(Abbreviated)]
e.g. New York, NY

---Installation---
pip install
python manage.py runserver