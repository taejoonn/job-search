from job_search.wsgi import application

app = application
